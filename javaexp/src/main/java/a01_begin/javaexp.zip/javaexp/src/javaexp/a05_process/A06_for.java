package javaexp.a05_process;

public class A06_for {

	public static void main(String[] args) {
		
		/*		
		# for문을 통한 반복문
		1. 특정 step단위로 반복문을 수행할 때, 사용된다.
		2. 기본 형식
			for(초기값;반복조건;증/감연산자){
				반복해서 수행할 구문..
			}
		*/
		for(int cnt=1;cnt<=10;cnt++) {
			System.out.println("카운트 업:"+cnt);
		}
	}

}
