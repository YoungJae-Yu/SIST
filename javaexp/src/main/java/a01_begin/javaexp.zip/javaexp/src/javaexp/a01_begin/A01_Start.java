package javaexp.a01_begin;

public class A01_Start {

	public static void main(String[] args) {
		// ctrl+(+/-) : 글자크기조절
		// ctrl+m : 전체화면/축소화면
		// 주석문 : 코드를 실할자지 않는 설명 내용
		System.out.println("안녕하세요! 자바 첫만남");
		//System.out.println("출력내용") : 출력 실행명령문
		//ctrl+s : 저장
		//ctrl+F11 : 실행

	}

}
