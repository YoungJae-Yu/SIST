package javaexp.a01_begin;

public class A05_javaClass {
		public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("자바실행");
	}

}
