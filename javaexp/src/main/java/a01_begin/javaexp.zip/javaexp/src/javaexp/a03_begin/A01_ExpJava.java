package javaexp.a03_begin;

public class A01_ExpJava {

	public static void main(String[] args) {
		System.out.println("반갑습니다. 자바!!");

	}

}
