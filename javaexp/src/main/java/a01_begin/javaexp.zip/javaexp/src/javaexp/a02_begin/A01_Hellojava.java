package javaexp.a02_begin;

public class A01_Hellojava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("안녕하세요 자바입니다.");
		// 마지막에 항상 ctrl+s(저장)
		// ctrl+f11s
		// ex) javaexp.a03_begin : 패키지명
		// 

	}

}
